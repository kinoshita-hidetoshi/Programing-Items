/*=========================================================*/
/*! @file
    @brief	StopWatchのためのヘッダファイル

    このファイル"StopWatch.h"は
	雑誌「C Magazine 2004年7月号 プログラミング研究会」のお題
	である「ストップウォッチの作成」のためのものです。

    @author	木下英俊
    @date   2004-07-04 新規作成
    $Revision: 1.0.0.0 $
*/
/*=========================================================*/


//
// マクロ宣言
//
#define		TRUE			1				//!< 正常_定義
#define		FALSE			0				//!< 異常_定義


//
// プロトタイプ宣言
//
int CheckKeyInput(void);					//!< キー入力チェック および 分岐処理
int DispMenu(void);							//!< キーメニュー表示
int DispProgressTime(void);					//!< 経過時間表示
int EndStopWatch(void);						//!< ストップウォッチプログラム 終了処理
int InitStopWatch(void);					//!< ストップウォッチプログラム 初期化処理
int main(void);								//!< main関数
