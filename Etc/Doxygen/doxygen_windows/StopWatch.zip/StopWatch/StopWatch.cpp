/*=========================================================*/
/*! @file
    @brief	StopWatchのためのＣソースファイル

    このファイル"StopWatch.c"は
	雑誌「C Magazine 2004年7月号 プログラミング研究会」のお題
	である「ストップウォッチの作成」のためのものです。

    @author	木下英俊
    @date   2004-07-04 新規作成
    $Revision: 1.0.0.0 $
*/
/*=========================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <sys\types.h>
#include <sys\timeb.h>
#include <conio.h>
#include "StopWatch.h"


//
// グローバル変数宣言
//
struct timeb	tbStartTime ;					//!< 計測 開始時刻
struct timeb	tbEndTime ;						//!< 計測 停止/経過時刻


//! プログラム状態
enum STATE {
	beforeStart,								//!< 時間計測前
	underMeasurement,							//!< 時間計測中
	dispLapTime,								//!< ラップ時間表示
	afterStop									//!< 時間計測終了
};



/*=========================================================*/
/*!
	プログラムの簡単な説明と
	キーメニューの表示を行います。

	@retval		TRUE	正常終了
	@retval		FALSE	異常終了
*/
/*=========================================================*/
int DispMenu(void)
{
	int		bRet ;


	/*========*/
	/* 前処理 */
	/*========*/
	bRet = TRUE ;


	/*========*/
	/* 処理部 */
	/*========*/
	printf("==============================================\n");
	printf("  StopWatch.exe,  Ver.1.0.0.0,  2004-07-04\n");
	printf("==============================================\n");
	printf("  [S] スタート/ストップ,  [L] ラップ時間表示\n");
	printf("----------------------------------------------\n");
	printf("  メニューを選んでください：");
	
	
	/*========*/
	/* 後処理 */
	/*========*/
	return bRet ;
}


/*=========================================================*/
/*!
	プログラム起動時のイニシャル処理を行います。

	@retval		TRUE	正常終了
	@retval		FALSE	異常終了
*/
/*=========================================================*/
int InitStopWatch(void)
{
	int		bRet ;


	/*========*/
	/* 前処理 */
	/*========*/
	bRet = TRUE ;


	/*========*/
	/* 処理部 */
	/*========*/
	// プログラム状態を「時間計測前」にする
	nowState	= beforeStart ;

	// メニュー表示
	DispMenu();


	/*========*/
	/* 後処理 */
	/*========*/
	return bRet ;
}


/*=========================================================*/
/*!
	時間計測終了後の計測結果表示と、
	プログラムの終了処理を行います。

	@retval		TRUE	正常終了
	@retval		FALSE	異常終了
*/
/*=========================================================*/
int EndStopWatch(void)
{
	int		bRet ;


	/*========*/
	/* 前処理 */
	/*========*/
	bRet = TRUE ;


	/*========*/
	/* 処理部 */
	/*========*/
	printf("---------------------------------------\n");
	printf("  経過時間は...\n");
	DispProgressTime();
	printf(" [秒] です。\n");
	printf("---------------------------------------\n");
	printf("  HIT ANY KEY !! ");
	while(!_kbhit());							// キー入力待ち
	while(_kbhit()){								// キー入力バッファを空にする。
		_getch();								// fflush(stdin)ではだめでした。
	}


	/*========*/
	/* 後処理 */
	/*========*/
	return bRet ;
}


/*=========================================================*/
/*!
	時間計測を開始してからの経過時間を表示する。 \n
	表示時間分解能は1/1000秒。 \n
	時間計測開始時間はグローバル変数 @ref tbStartTime より取得する。
	プログラム状態が時間計測終了(@ref afterStop)である場合、時間計測終了時間は @ref tbEndTime より
	取得する。 \n

	@retval		TRUE	正常終了
	@retval		FALSE	異常終了
*/
/*=========================================================*/
int DispProgressTime(void)
{
	int				bRet ;						// 関数戻り値
	long			ttProgressSec ;				// 開始からの経過秒
	long			usProgressMilSec ;			// 開始からの経過ﾐﾘ秒


	/*========*/
	/* 前処理 */
	/*========*/
	bRet = TRUE ;


	/*========*/
	/* 処理部 */
	/*========*/
	switch(nowState){
	case underMeasurement :
	case dispLapTime :
		/*==============*/
		/* 現在時刻取得 */
		/*==============*/
		ftime(&tbEndTime);

	case afterStop :
		/*================================*/
		/* 時間計測開始からの経過時間計算 */
		/*================================*/
		ttProgressSec = (long)(tbEndTime.time - tbStartTime.time) ;
		usProgressMilSec = tbEndTime.millitm - tbStartTime.millitm ;
		if (usProgressMilSec < 0){
			ttProgressSec-- ;					// 経過秒の補正処理
			usProgressMilSec += 1000 ;
		}

		/*==============*/
		/* 経過時間表示 */
		/*==============*/
		printf("\r  %d.",   ttProgressSec);
		printf("%03d", usProgressMilSec);

		break ;

	default:
		break ;
	}


	/*========*/
	/* 後処理 */
	/*========*/
	return bRet ;
}


/*=========================================================*/
/*!
	キー入力の有/無を確認し、キー入力が無ければ特に処理をせずに終了する。
	キー入力があった場合は、各入力に対応する処理を実行する。 \n
	プログラム状態は４状態（時間計測前、時間計測中、ラップ時間表示、時間計測終了）
	を定義しているが、本関数でキーを受け付ける状態とキー入力は
	- 時間計測前：（'s' or 'S' を受け付ける）
	- 時間計測中：（'s' or 'S' or 'l' or 'L' を受け付ける）

	だけである。それ以外は無視する。
	
	@param [in]	nowState	プログラム状態

	@retval		TRUE		正常終了
	@retval		FALSE		異常終了
*/
/*=========================================================*/
int CheckKeyInput( STATE &nowState)
{
	int			bRet ;
	int			wInpKey ;
	static int	iLaptimeCount=0 ;


	/*========*/
	/* 前処理 */
	/*========*/
	bRet = TRUE ;


	/*========*/
	/* 処理部 */
	/*========*/
	if (_kbhit()){
		wInpKey = _getch();
		if (wInpKey == EOF){
			// getcがファイル終端を検出
			bRet = FALSE ;
			return bRet ;
		}

		// もしキー入力がったら、現在の状態に従った処理を実行
		switch(nowState){
		case beforeStart :
			/*==================*/
			/* 計測開始前のとき */
			/*==================*/
			switch(wInpKey){
			case 's' :
			case 'S' :
				/*==============*/
				/* 時間計測開始 */
				/*==============*/
				nowState = underMeasurement ;
				ftime(&tbStartTime);
				printf("\n");
				printf("---------------------------------------\n");
				printf("  時間計測を開始しました。\n");
				printf("  0.000 [秒] ； 計測開始\n");
				break ;

			default:
				break ;
			}
			break ;
		

		case underMeasurement :
			/*==============*/
			/* 計測中のとき */
			/*==============*/
			switch(wInpKey){
			case 's' :
			case 'S' :
				/*==============*/
				/* 時間計測終了 */
				/*==============*/
				nowState = afterStop ;				// プログラム状態変更

				// 停止時間表示
				DispProgressTime();
				printf(" [秒] ； 計測停止\n");
				printf("  時間計測を停止しました。\n");
				break ;
			
			case 'l' :
			case 'L' :
				/*================*/
				/* ラップ時間表示 */
				/*================*/
				nowState = dispLapTime ;			// プログラム状態変更
				iLaptimeCount++ ;					// ラップ表示回数 更新

				// ラップ時間表示
				DispProgressTime();
				printf(" [秒] ； ラップ時間(%d)\n", iLaptimeCount);
				
				// 後処理
				nowState = underMeasurement ;
				break ;

			default:
				break ;
			}
			break ;
		
		default:
			bRet = FALSE ;
			break ;
		}
	}


	/*========*/
	/* 後処理 */
	/*========*/
	return bRet ;
}


/*=========================================================*/
/*!
	プログラム唯一の @ref main 関数です。 \n
	プログラムのイニシャル処理( @ref InitStopWatch )を行った後は、
	経過時間表示( @ref DispProgressTime )と
	キー入力チェック( @ref CheckKeyInput )を
	ポーリングで繰り返すだけの単純な内容です。\n
	時間計測を終了するとメインループを抜け、
	プログラムの終了処理( @ref EndStopWatch )を実行した後に
	プログラムを終了します。

	@retval		EXIT_SUCCESS	正常終了
	@retval		EXIT_FAILURE	異常終了
	
*/
/*=========================================================*/
int main(void)
{
	STATE nowState;								//!< プログラムの今の状態
	
	/*========*/
	/* 前処理 */
	/*========*/
	InitStopWatch();							// StopWatchの前処理


	/*========*/
	/* 処理部 */
	/*========*/
	while(nowState != afterStop){
		if (!DispProgressTime()){				// 経過時間表示
			break ;
		}
		if (!CheckKeyInput(nowState)){			// ｷｰ入力ﾁｪｯｸと対応する処理
			break ;
		}
	}


	/*========*/
	/* 後処理 */
	/*========*/
	EndStopWatch();								// StopWatchの後処理

	return EXIT_SUCCESS ;
}
