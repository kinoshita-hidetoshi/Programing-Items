﻿/*

"Levenshtein"

Copyright (c) 2015 KINOSHITA Hidetoshi

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF 
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

--------------------------------------------------------------------------

"Levenshtein"

Copyright (c) 2015 木下英俊

以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル（以下「ソフ
トウェア」）の複製を取得するすべての人に対し、ソフトウェアを無制限に扱うこ
とを無償で許可します。これには、ソフトウェアの複製を使用、複写、変更、結合
、掲載、頒布、サブライセンス、および／または販売する権利、およびソフトウェ
アを提供する相手に同じことを許可する権利も無制限に含まれます。
 
上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要な
部分に記載するものとします。 

ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの保
証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、お
よび権利非侵害についての保証も含みますが、それに限定されるものではありませ
ん。作者または著作権者は、契約行為、不法行為、またはそれ以外であろうと、ソ
フトウェアに起因または関連し、あるいはソフトウェアの使用またはその他の扱い
によって生じる一切の請求、損害、その他の義務について何らの責任も負わないも
のとします。

*/

using System;

namespace LevenshteinCs
{
	class Program
	{
		static void Main(string[] args)
		{
#if true
			string str1 = "apple";
			string str2 = "maple";
#else
			string str1 = "木下英俊";
			string str2 = "木下郁世";
#endif

			int distance = GetLevenshtein(str1, str2);

			Console.WriteLine("\n\"{0}\" と \"{1}\" のレーベンシュタイン距離は \"{2}\" です。", str1, str2, distance);

			Console.Write("\nHIT [Enter] KEY !! ");
			Console.ReadLine();
		}

		private static int GetLevenshtein(string s1, string s2)
		{
			string str1 = " " + s1;
			string str2 = " " + s2;
			int distance = 0;
			int[,] table = new int[str2.Length, str1.Length];

			// テーブル初期化
			for (int i = 0; i < str1.Length; ++i)
			{
				table[0, i] = i;
			}
			for (int i = 0; i < str2.Length; ++i)
			{
				table[i, 0] = i;
			}

			// 計算
			for (int y = 1; y < str2.Length; ++y)
			{
				for (int x = 1; x < str1.Length; ++x)
				{
					table[y, x] = min(table[y - 1, x] + 1, table[y, x - 1] + 1, table[y - 1, x - 1] + (str1[x] != str2[y] ? 1 : 0));
				}
			}

			print2DArray(str1, str2, table);

			distance = table[str2.Length - 1, str1.Length - 1];

			return distance;
		}

		private static int min(int p1, int p2, int p3)
		{
			return Math.Min(p1, Math.Min(p2, p3));
		}

		private static void print2DArray(string s1, string s2, int[,] table)
		{
			Console.WriteLine("Table[{0},{1}]", table.GetLength(0), table.GetLength(1) );
			System.Diagnostics.Trace.WriteLine("x=" + table.GetLength(0) + ", y=" + table.GetLength(1));

			Console.Write("  ");
			for (int i = 0; i < s1.Length; ++i) { 
				Console.Write("{0} ",s1[i]);
			}
			Console.WriteLine();
			for (int y = 0; y < table.GetLength(0); ++y)
			{
				Console.Write("{0} ", s2[y]);
				for (int x = 0; x < table.GetLength(1); ++x)
				{
					Console.Write(table[y, x] + " ");
				}
				Console.WriteLine();
			}
		}
	}
}
