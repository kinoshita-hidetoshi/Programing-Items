﻿//
// 参考ＵＲＬ
// http://blogs.wankuma.com/torikobito/archive/2007/05/29/78651.aspx （その１）
// http://blogs.wankuma.com/torikobito/archive/2007/05/29/78684.aspx （その３）
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace databinding_01
{
	public partial class Form1 : Form
	{
		private Person _person;

		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			MessageBox.Show(_person.name, "text確認", MessageBoxButtons.OK);
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			_person = new Person();

			textBox1.DataBindings.Add("Text", _person, "name");
		}

		private void button3_Click(object sender, EventArgs e)
		{
			_person.name = "名前が変わりました。";
		}
	}
}
