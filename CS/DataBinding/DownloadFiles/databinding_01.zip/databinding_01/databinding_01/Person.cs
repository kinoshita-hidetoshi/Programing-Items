﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel; // INotifyPropertyChanged

namespace databinding_01
{
	class Person : INotifyPropertyChanged
	{

		private string _name;
		public string name
		{
			set{
				_name = value;
				NotifyPropertyChanged("name");
			}
			get{
				return _name;
			}
		}


		#region INotifyPropertyChanged

		public event PropertyChangedEventHandler PropertyChanged;

		void NotifyPropertyChanged(string info)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}

		#endregion // INotifyPropertyChanged
	}
}
