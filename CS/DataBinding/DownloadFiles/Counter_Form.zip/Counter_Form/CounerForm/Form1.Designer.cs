﻿namespace CounerForm
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナ変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナで生成されたコード

		/// <summary>
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.btnIncrement = new System.Windows.Forms.Button();
			this.btnDecrement = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnQuit = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox1.Location = new System.Drawing.Point(12, 12);
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.Size = new System.Drawing.Size(404, 76);
			this.textBox1.TabIndex = 0;
			this.textBox1.TabStop = false;
			this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// btnIncrement
			// 
			this.btnIncrement.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnIncrement.Location = new System.Drawing.Point(12, 95);
			this.btnIncrement.Name = "btnIncrement";
			this.btnIncrement.Size = new System.Drawing.Size(125, 64);
			this.btnIncrement.TabIndex = 1;
			this.btnIncrement.Text = "+";
			this.btnIncrement.UseVisualStyleBackColor = true;
			this.btnIncrement.Click += new System.EventHandler(this.btnIncrement_Click);
			// 
			// btnDecrement
			// 
			this.btnDecrement.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDecrement.Location = new System.Drawing.Point(151, 95);
			this.btnDecrement.Name = "btnDecrement";
			this.btnDecrement.Size = new System.Drawing.Size(125, 64);
			this.btnDecrement.TabIndex = 2;
			this.btnDecrement.Text = "-";
			this.btnDecrement.UseVisualStyleBackColor = true;
			this.btnDecrement.Click += new System.EventHandler(this.btnDecrement_Click);
			// 
			// btnClear
			// 
			this.btnClear.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClear.Location = new System.Drawing.Point(290, 95);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(125, 64);
			this.btnClear.TabIndex = 3;
			this.btnClear.Text = "Clear";
			this.btnClear.UseVisualStyleBackColor = true;
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// btnQuit
			// 
			this.btnQuit.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuit.Location = new System.Drawing.Point(291, 185);
			this.btnQuit.Name = "btnQuit";
			this.btnQuit.Size = new System.Drawing.Size(125, 64);
			this.btnQuit.TabIndex = 0;
			this.btnQuit.Text = "Quit";
			this.btnQuit.UseVisualStyleBackColor = true;
			this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(428, 261);
			this.Controls.Add(this.btnQuit);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.btnDecrement);
			this.Controls.Add(this.btnIncrement);
			this.Controls.Add(this.textBox1);
			this.Name = "Form1";
			this.Text = "Counter";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button btnIncrement;
		private System.Windows.Forms.Button btnDecrement;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnQuit;
	}
}

