﻿using JoyStickController;
using System;
using System.Windows.Forms;

namespace test_JoyStick
{
    public partial class Form1 : Form
	{
		private JoyStick _joyStick1 = new JoyStick(JOYSTICK_ID.JOYSTICKID1);
		private JoyStick _joyStick2 = new JoyStick(JOYSTICK_ID.JOYSTICKID2);

		public Form1()
		{
			InitializeComponent();
		}

		private void Timer1_Tick(object sender, EventArgs e)
		{
			// JoyStick 1
			{
				//JOYINFO joyInfo1 =  _joyStick1.GetPos();
				JOYINFOEX joyInfoEx1 = _joyStick1.GetPosEx();

				if (_joyStick1.GetMMRESULT() == MMRESULT.JOYERR_NOERROR) {
					tb_x_1.Text = joyInfoEx1.dwXpos.ToString();
					tb_y_1.Text = joyInfoEx1.dwYpos.ToString();
					tb_z_1.Text = joyInfoEx1.dwZpos.ToString();
					tb_buttons_1.Text = joyInfoEx1.dwButtons.ToString("X8");
                    tb_JoyStick1_ID.Text = (_joyStick1.JoystickId).ToString();
				}
				else
				{
                    if (tb_x_1.Text != "")
                    {
                        JoyStick.JoyConfigChanged();
                    }
                    tb_x_1.Text = "";
					tb_y_1.Text = "";
					tb_z_1.Text = "";
					tb_buttons_1.Text = "";
                    tb_JoyStick1_ID.Text = "";
                }
			}


			// JoyStick 2
			{
				//JOYINFO joyInfo2 = _joyStick2.GetPos();
				JOYINFOEX joyInfoEx2 = _joyStick2.GetPosEx();

				if (_joyStick2.GetMMRESULT() == MMRESULT.JOYERR_NOERROR)
				{
					tb_x_2.Text = joyInfoEx2.dwXpos.ToString();
					tb_y_2.Text = joyInfoEx2.dwYpos.ToString();
					tb_z_2.Text = joyInfoEx2.dwZpos.ToString();
					tb_buttons_2.Text = joyInfoEx2.dwButtons.ToString("X8");
                    tb_JoyStick2_ID.Text = (_joyStick2.JoystickId).ToString();
                }
                else
				{
                    if (tb_x_2.Text != "")
                    {
                        JoyStick.JoyConfigChanged();
                    }
                    tb_x_2.Text = "";
					tb_y_2.Text = "";
					tb_z_2.Text = "";
					tb_buttons_2.Text = "";
                    tb_JoyStick2_ID.Text = "";
                }
            }
		}

		private void Button1_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
