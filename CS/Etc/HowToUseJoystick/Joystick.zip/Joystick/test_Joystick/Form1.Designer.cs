﻿namespace test_JoyStick
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tb_x_1 = new System.Windows.Forms.TextBox();
            this.tb_y_1 = new System.Windows.Forms.TextBox();
            this.tb_z_1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_buttons_1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_buttons_2 = new System.Windows.Forms.TextBox();
            this.tb_z_2 = new System.Windows.Forms.TextBox();
            this.tb_y_2 = new System.Windows.Forms.TextBox();
            this.tb_x_2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tb_JoyStick1_ID = new System.Windows.Forms.TextBox();
            this.tb_JoyStick2_ID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "JoyStick1";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // tb_x_1
            // 
            this.tb_x_1.Location = new System.Drawing.Point(89, 38);
            this.tb_x_1.Name = "tb_x_1";
            this.tb_x_1.ReadOnly = true;
            this.tb_x_1.Size = new System.Drawing.Size(100, 19);
            this.tb_x_1.TabIndex = 1;
            // 
            // tb_y_1
            // 
            this.tb_y_1.Location = new System.Drawing.Point(89, 63);
            this.tb_y_1.Name = "tb_y_1";
            this.tb_y_1.ReadOnly = true;
            this.tb_y_1.Size = new System.Drawing.Size(100, 19);
            this.tb_y_1.TabIndex = 2;
            // 
            // tb_z_1
            // 
            this.tb_z_1.Location = new System.Drawing.Point(89, 91);
            this.tb_z_1.Name = "tb_z_1";
            this.tb_z_1.ReadOnly = true;
            this.tb_z_1.Size = new System.Drawing.Size(100, 19);
            this.tb_z_1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "x";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "y";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "z";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "buttons";
            // 
            // tb_buttons_1
            // 
            this.tb_buttons_1.Location = new System.Drawing.Point(89, 117);
            this.tb_buttons_1.Name = "tb_buttons_1";
            this.tb_buttons_1.ReadOnly = true;
            this.tb_buttons_1.Size = new System.Drawing.Size(100, 19);
            this.tb_buttons_1.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(258, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 12);
            this.label6.TabIndex = 10;
            this.label6.Text = "buttons";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(258, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(10, 12);
            this.label7.TabIndex = 11;
            this.label7.Text = "z";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(258, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(11, 12);
            this.label8.TabIndex = 12;
            this.label8.Text = "y";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(258, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(11, 12);
            this.label9.TabIndex = 13;
            this.label9.Text = "x";
            // 
            // tb_buttons_2
            // 
            this.tb_buttons_2.Location = new System.Drawing.Point(314, 117);
            this.tb_buttons_2.Name = "tb_buttons_2";
            this.tb_buttons_2.ReadOnly = true;
            this.tb_buttons_2.Size = new System.Drawing.Size(100, 19);
            this.tb_buttons_2.TabIndex = 8;
            // 
            // tb_z_2
            // 
            this.tb_z_2.Location = new System.Drawing.Point(314, 91);
            this.tb_z_2.Name = "tb_z_2";
            this.tb_z_2.ReadOnly = true;
            this.tb_z_2.Size = new System.Drawing.Size(100, 19);
            this.tb_z_2.TabIndex = 9;
            // 
            // tb_y_2
            // 
            this.tb_y_2.Location = new System.Drawing.Point(314, 63);
            this.tb_y_2.Name = "tb_y_2";
            this.tb_y_2.ReadOnly = true;
            this.tb_y_2.Size = new System.Drawing.Size(100, 19);
            this.tb_y_2.TabIndex = 7;
            // 
            // tb_x_2
            // 
            this.tb_x_2.Location = new System.Drawing.Point(314, 38);
            this.tb_x_2.Name = "tb_x_2";
            this.tb_x_2.ReadOnly = true;
            this.tb_x_2.Size = new System.Drawing.Size(100, 19);
            this.tb_x_2.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(237, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 12);
            this.label10.TabIndex = 5;
            this.label10.Text = "JoyStick2";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(339, 306);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Quit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(35, 150);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 12);
            this.label12.TabIndex = 17;
            this.label12.Text = "ID";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(258, 150);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 12);
            this.label13.TabIndex = 18;
            this.label13.Text = "ID";
            // 
            // tb_JoyStick1_ID
            // 
            this.tb_JoyStick1_ID.Location = new System.Drawing.Point(89, 150);
            this.tb_JoyStick1_ID.Name = "tb_JoyStick1_ID";
            this.tb_JoyStick1_ID.ReadOnly = true;
            this.tb_JoyStick1_ID.Size = new System.Drawing.Size(100, 19);
            this.tb_JoyStick1_ID.TabIndex = 19;
            // 
            // tb_JoyStick2_ID
            // 
            this.tb_JoyStick2_ID.Location = new System.Drawing.Point(314, 147);
            this.tb_JoyStick2_ID.Name = "tb_JoyStick2_ID";
            this.tb_JoyStick2_ID.ReadOnly = true;
            this.tb_JoyStick2_ID.Size = new System.Drawing.Size(100, 19);
            this.tb_JoyStick2_ID.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 341);
            this.Controls.Add(this.tb_JoyStick2_ID);
            this.Controls.Add(this.tb_JoyStick1_ID);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tb_buttons_2);
            this.Controls.Add(this.tb_z_2);
            this.Controls.Add(this.tb_y_2);
            this.Controls.Add(this.tb_x_2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_buttons_1);
            this.Controls.Add(this.tb_z_1);
            this.Controls.Add(this.tb_y_1);
            this.Controls.Add(this.tb_x_1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "test_JoyStick";
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.TextBox tb_x_1;
		private System.Windows.Forms.TextBox tb_y_1;
		private System.Windows.Forms.TextBox tb_z_1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox tb_buttons_1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox tb_buttons_2;
		private System.Windows.Forms.TextBox tb_z_2;
		private System.Windows.Forms.TextBox tb_y_2;
		private System.Windows.Forms.TextBox tb_x_2;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tb_JoyStick1_ID;
        private System.Windows.Forms.TextBox tb_JoyStick2_ID;
    }
}

