﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RandomBytes
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		private TestData testData = new TestData();
#if false
		private Thread thread;
		private bool bFinish = false;
#endif


		public MainWindow()
		{
			InitializeComponent();
		}

		private void Button_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			// TODO: ここにイベント ハンドラーのコードを追加します。
//			bFinish = true;
			Close();
		}

		void UpdateData()
		{
			// 乱数で10バイトを作成
			testData.UpdateData();
		}

		private void Click_UpdateData(object sender, RoutedEventArgs e)
		{
			UpdateData();
		}

		private void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			var binding = new Binding();

			binding.Source = testData;
			binding.Path = new PropertyPath("data");
			binding.Converter = new TestConverter();
			binding.Mode = BindingMode.OneWay;

			data_view.SetBinding(TextBlock.TextProperty, binding);

			UpdateData();

#if false
			thread = new Thread(ThreadTask);
			thread.IsBackground = true;
			thread.Start();
#endif
		}
	
#if false
		private void ThreadTask()
		{
			while (!bFinish)
			{
				Thread.Sleep(5000);
				UpdateData();
			}
		}
#endif

	}


	public class TestData : INotifyPropertyChanged
	{
		private const int DataBytes = 10;
		private byte[] _data = new byte[DataBytes];
		private Random random = new Random();

		public byte[] data
		{
			get
			{
				return _data;
			}
		}

		public TestData()
		{
		}

		public void UpdateData()
		{
			random.NextBytes(data);

			NotifyPropertyChanged("data");
		}


		#region INotifyPropertyChanged

		public event PropertyChangedEventHandler PropertyChanged;

		void NotifyPropertyChanged(string info)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}

		#endregion // INotifyPropertyChanged
	}


	[ValueConversion(typeof(string), typeof(byte[]))]
	public class TestConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			var data = (byte[])value;

			string temp = "";

			foreach (byte oneByte in data)
			{
				temp += oneByte.ToString("X2");
			}

			return temp;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return null;
		}
	}
}
