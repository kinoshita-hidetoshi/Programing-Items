﻿/*

Copyright (c) 2012 KINOSHITA Hidetoshi

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF 
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

--------------------------------------------------------------------------

Copyright (c) 2012 木下英俊

以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル（以下「ソフ
トウェア」）の複製を取得するすべての人に対し、ソフトウェアを無制限に扱うこ
とを無償で許可します。これには、ソフトウェアの複製を使用、複写、変更、結合
、掲載、頒布、サブライセンス、および／または販売する権利、およびソフトウェ
アを提供する相手に同じことを許可する権利も無制限に含まれます。
 
上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要な
部分に記載するものとします。 

ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの保
証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、お
よび権利非侵害についての保証も含みますが、それに限定されるものではありませ
ん。作者または著作権者は、契約行為、不法行為、またはそれ以外であろうと、ソ
フトウェアに起因または関連し、あるいはソフトウェアの使用またはその他の扱い
によって生じる一切の請求、損害、その他の義務について何らの責任も負わないも
のとします。

*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using CounterDll;


namespace CounterWPF
{
	/// <summary>
	/// Window1.xaml の相互作用ロジック
	/// </summary>
	public partial class Window1 : Window
	{
		private Counter _counter = new Counter();


		public Window1()
		{
			InitializeComponent();
//			DataContext = _counter;
			DataContext = new
			{
				counter = _counter,
			};
			Button_Click_Clear(this, new RoutedEventArgs());
		}

		private void Button_Click_Quit(object sender, System.Windows.RoutedEventArgs e)
		{
			// TODO: ここにイベント ハンドラーのコードを追加します。
			Close();
		}

		private void Button_Click_Increment(object sender, System.Windows.RoutedEventArgs e)
		{
			_counter.Increment();

			if (_counter.CountValue == _counter.CountMax)
			{
				Button_Increment.IsEnabled = false;
			}
			if (_counter.CountValue != _counter.CountMin)
			{
				Button_Decrement.IsEnabled = true;
			}
		}

		private void Button_Click_Decrement(object sender, System.Windows.RoutedEventArgs e)
		{
			_counter.Decrement();

			if (_counter.CountValue != _counter.CountMax)
			{
				Button_Increment.IsEnabled = true;
			}
			if (_counter.CountValue == _counter.CountMin)
			{
				Button_Decrement.IsEnabled = false;
			}
		}

		private void Button_Click_Clear(object sender, System.Windows.RoutedEventArgs e)
		{
			_counter.Clear();
			Button_Increment.IsEnabled = true;
			Button_Decrement.IsEnabled = false;
		}

		private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (MessageBox.Show("プログラムを終了してよろしいですか？", "終了確認", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
			{
				// プログラムを終了する
			}
			else
			{
				// プログラムを終了しない
				e.Cancel = true;
			}
		}
	}
}
