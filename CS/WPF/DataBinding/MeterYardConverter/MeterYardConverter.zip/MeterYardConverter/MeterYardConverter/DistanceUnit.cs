﻿using System.Collections.Generic;

namespace MeterYardConverter
{
	public class DistanceUnit
	{
		public string Name { get; set; }
		public double Coefficient { get; set; }
		public override string ToString()
		{
			return this.Name;
		}
	}


	/// <summary>
	/// メートル単位を表すクラス
	/// </summary>
	public class MetricUnit : DistanceUnit
	{
		private static List<MetricUnit> _units = new List<MetricUnit>
		{
			new MetricUnit {Name="mm", Coefficient=1, },
			new MetricUnit {Name="cm", Coefficient=10, },
			new MetricUnit {Name="m", Coefficient=10*100, },
			new MetricUnit {Name="km", Coefficient=10*100*1000, },
		};

		public static ICollection<MetricUnit> Units { get { return _units; } }

		public double FromImperialUnit(ImperialUnit unit, double value)
		{
			return (value * unit.Coefficient) * 25.4 / this.Coefficient;
		}
	}


	/// <summary>
	/// ヤード単位を表すクラス
	/// </summary>
	public class ImperialUnit : DistanceUnit
	{
		private static List<ImperialUnit> _units = new List<ImperialUnit>
		{
			new ImperialUnit {Name="in", Coefficient=1, },
			new ImperialUnit {Name="ft", Coefficient=12, },
			new ImperialUnit {Name="yd", Coefficient=12*3, },
			new ImperialUnit {Name="ml", Coefficient=12*3*1760, },
		};

		public static ICollection<ImperialUnit> Units { get { return _units; } }

		public double FromMetricUnit(MetricUnit unit, double value)
		{
			return (value * unit.Coefficient) / 25.4 / this.Coefficient;
		}
	}
}
