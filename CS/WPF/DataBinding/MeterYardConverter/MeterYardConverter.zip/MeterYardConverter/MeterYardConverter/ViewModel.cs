﻿
using System.ComponentModel;                // INotifyPropertyChanged
using System.Runtime.CompilerServices;      // CallerMemberName

namespace MeterYardConverter
{
	public class ViewModel : INotifyPropertyChanged
	{
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>
		/// 
		/// </summary>
		/// <remarks>[CallerMemberName] は .NET4.5 以降で使用できます。</remarks>
		/// <param name="propertyName"></param>
		protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}
	}
}
