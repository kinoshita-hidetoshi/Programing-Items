﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Input;			// ICommand


namespace MeterYardConverter
{
	class MainWindowVIewModel : ViewModel
	{
		// 上のTextBoxで入力されている値
		private double _metricValue;
		// 下のTextBoxで入力されている値
		private double _imperialValue;

		// ▲ボタンで呼ばれるコマンド
		public ICommand ImperialUnitToMetricUnit { get; private set; }
		// ▼ボタンで呼ばれるコマンド
		public ICommand MetricUnitToImperialUnit { get; private set; }

		// 上のComboBoxで選択されている単位
		public MetricUnit CurrentMetricUnit { get; set; }
		// 下のComboBoxで選択されている単位
		public ImperialUnit CurrentImperialUnit { get; set; }


		public double MetricValue
		{
			get { return this._metricValue; }
			set
			{
				this._metricValue = value;
				this.OnPropertyChanged();
			}
		}

		public double ImperialValue
		{
			get { return this._imperialValue; }
			set
			{
				this._imperialValue = value;
				this.OnPropertyChanged();
			}
		}

		public MainWindowVIewModel()
		{
			// CurrnetMetricUnit の初期化
			this.CurrentMetricUnit = MetricUnit.Units.First();
			// CurrentImperialUnit の初期化
			this.CurrentImperialUnit = ImperialUnit.Units.First();

			// ICommand MetricUnitToImperialUnit の初期化
			this.MetricUnitToImperialUnit = new DelegateCommand(() =>
			{
				this.ImperialValue = this.CurrentImperialUnit.FromMetricUnit(this.CurrentMetricUnit, this.MetricValue);
			});

			// ICommand ImperialUnitToMetricUnit の初期化
			this.ImperialUnitToMetricUnit = new DelegateCommand(()=> {
				this.MetricValue = this.CurrentMetricUnit.FromImperialUnit(this.CurrentImperialUnit, this.ImperialValue);
			});
		}
	}
}
