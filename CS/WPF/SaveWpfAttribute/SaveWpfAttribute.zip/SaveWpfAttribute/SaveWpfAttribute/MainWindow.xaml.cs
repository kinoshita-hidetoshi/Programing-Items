﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SaveWpfAttribute
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			this.InitializeComponent();

			// オブジェクト作成に必要なコードをこの点の下に挿入します。
		}

		private void Window_Closed(object sender, System.EventArgs e)
		{
			// TODO: ここにイベント ハンドラーのコードを追加します。
			Properties.Settings.Default.Save();
		}
	}
}