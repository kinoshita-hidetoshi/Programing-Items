﻿using System;
using System.Windows;                   // GridLength, ContentElement.BeginAnimation
using System.Windows.Controls;

using System.Windows.Media.Animation;   // EasingFunctionBase, CubicEase


namespace test_GridSplitter_02
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool bMenuOpened = true;
        private GridLength menuWidthOrg;
        private EasingFunctionBase ease = new CubicEase();
        private GridLength fromMenuWidth;
        private GridLength toMenuWidth;


        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var glaMenu = new GridLengthAnimation();

            if ( bMenuOpened == true)
            {
                // menu を閉じる
                bMenuOpened = false;

                // GridSplitter を動作できるようにする
                //menuWidth.MinWidth = 0; menuWidth.MaxWidth = 500;

                menuWidthOrg = menuWidth.Width;
                fromMenuWidth = menuWidth.Width;
                toMenuWidth = new GridLength(0.0, GridUnitType.Star);

                // EasingFunction definitions.
                ease.EasingMode = EasingMode.EaseInOut;
                glaMenu.EasingFunction = ease;
            }
            else
            {
                // menu を開く
                bMenuOpened = true;

                // GridSplitter を動作できるようにする
                //menuWidth.MinWidth = 0; menuWidth.MaxWidth = 500;

                //fromMenuWidth = new GridLength(menuWidth.ActualWidth);
                fromMenuWidth = menuWidth.Width;
                toMenuWidth = menuWidthOrg;

                // EasingFunction definitions.
                ease.EasingMode = EasingMode.EaseInOut;
                glaMenu.EasingFunction = ease;
            }

            glaMenu.Completed += GlaMenu_Completed;
            glaMenu.Duration = new Duration(TimeSpan.FromSeconds(0.5));
            //glaMenu.FillBehavior = FillBehavior.HoldEnd;
            glaMenu.FillBehavior = FillBehavior.Stop;
            glaMenu.From = fromMenuWidth;
            glaMenu.To = toMenuWidth;
            menuWidth.BeginAnimation(ColumnDefinition.WidthProperty, glaMenu);
        }

        private void GlaMenu_Completed(object sender, EventArgs e)
        {
            menuWidth.Width = toMenuWidth;

            if ( bMenuOpened)
            {
                btnOpenClose.Content = "⇐";
                menuGlidSplitter.IsEnabled = true;
            }
            else
            {
                btnOpenClose.Content = "⇒";
                menuGlidSplitter.IsEnabled = false;
            }
        }
    }
}
