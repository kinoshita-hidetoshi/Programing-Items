﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace testDragAndDrop2
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void Image01_Drop(object sender, DragEventArgs e)
		{
			String[] files = e.Data.GetData(DataFormats.FileDrop) as string[];

			foreach (string filename in files)
			{
				System.Diagnostics.Trace.WriteLine(filename);
			}

			if (files.Length > 0)
			{
				try
				{
					BitmapImage bi = new BitmapImage();
					bi.BeginInit();
					bi.UriSource = new Uri(files[0]);
					bi.EndInit();
					Image01.Stretch = Stretch.Uniform;
					Image01.Source = bi;
				}
				catch (NotSupportedException)
				{
					MessageBox.Show("ファイル\"" + files[0] + "\" はサポート外のファイルフォーマットです。", "ERRORメッセージ", MessageBoxButton.OK, MessageBoxImage.Warning);
				}
			}

			e.Handled = true;
		}

		private void Image01_DragOver(object sender, DragEventArgs e)
		{
			e.Effects = DragDropEffects.Copy;
			e.Handled = true;
		}
	}
}
