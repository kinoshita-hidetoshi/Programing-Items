﻿//      *********    このファイルを編集しないでください     *********
//      このファイルはデザイン ツールにより作成されました。
//      このファイルに変更を加えるとエラーが発生する場合があります。
namespace Expression.Blend.SampleData.SampleDataSource
{
    using System; 
    using System.ComponentModel;

// 実稼働アプリケーション内にあるサンプル データのフットプリントを大幅に減らすには、
// DISABLE_SAMPLE_DATA 条件付コンパイル定数を設定して、実行時のサンプル データを無効にすることができます。
#if DISABLE_SAMPLE_DATA
    internal class SampleDataSource { }
#else

    public class SampleDataSource : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public SampleDataSource()
        {
            try
            {
                Uri resourceUri = new Uri("/test_01;component/SampleData/SampleDataSource/SampleDataSource.xaml", UriKind.RelativeOrAbsolute);
                System.Windows.Application.LoadComponent(this, resourceUri);
            }
            catch
            {
            }
        }

        private ItemCollection _Collection = new ItemCollection();

        public ItemCollection Collection
        {
            get
            {
                return this._Collection;
            }
        }
    }

    public class Item : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private string _name = string.Empty;

        public string name
        {
            get
            {
                return this._name;
            }

            set
            {
                if (this._name != value)
                {
                    this._name = value;
                    this.OnPropertyChanged("name");
                }
            }
        }

        private bool _check = false;

        public bool check
        {
            get
            {
                return this._check;
            }

            set
            {
                if (this._check != value)
                {
                    this._check = value;
                    this.OnPropertyChanged("check");
                }
            }
        }

        private string _mail = string.Empty;

        public string mail
        {
            get
            {
                return this._mail;
            }

            set
            {
                if (this._mail != value)
                {
                    this._mail = value;
                    this.OnPropertyChanged("mail");
                }
            }
        }

        private string _sample_string = string.Empty;

        public string sample_string
        {
            get
            {
                return this._sample_string;
            }

            set
            {
                if (this._sample_string != value)
                {
                    this._sample_string = value;
                    this.OnPropertyChanged("sample_string");
                }
            }
        }

        private System.Windows.Media.ImageSource _image = null;

        public System.Windows.Media.ImageSource image
        {
            get
            {
                return this._image;
            }

            set
            {
                if (this._image != value)
                {
                    this._image = value;
                    this.OnPropertyChanged("image");
                }
            }
        }

        private string _company = string.Empty;

        public string company
        {
            get
            {
                return this._company;
            }

            set
            {
                if (this._company != value)
                {
                    this._company = value;
                    this.OnPropertyChanged("company");
                }
            }
        }
    }

    public class ItemCollection : System.Collections.ObjectModel.ObservableCollection<Item>
    { 
    }
#endif
}
