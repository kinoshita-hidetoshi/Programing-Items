﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfWindow
{
	public class FinishEventArgs : EventArgs { }
	public delegate void FinishInputHandler(object sender, FinishEventArgs e);

	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		public event FinishInputHandler FinishInputEvent;

		public string name
		{set;get;}

		public string phone
		{ set; get; }

		public string address
		{ set; get; }

		public MainWindow()
		{
			InitializeComponent();
		}

		private void Button_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			// 入力完了をイベント通知
			if (FinishInputEvent != null)
			{
				FinishEventArgs finishEventArgs = new FinishEventArgs();

				FinishInputEvent(this, finishEventArgs);
			}

			// Windowを閉じる
			Close();
		}
	}
}
