﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Windows.Forms.Integration;	// ElementHost
using WpfWindow;	// MainWindow


namespace FormSideAp
{
	public partial class Form1 : Form
	{
		private MainWindow window = null;

		public Form1()
		{
			InitializeComponent();
		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ( MessageBox.Show("終了してよろしいですか", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== System.Windows.Forms.DialogResult.No)
			{
				// 終了しない
				e.Cancel = true;
			}
		}

		private void btnNewWindow_Show(object sender, EventArgs e)
		{
			window = new MainWindow();

			window.FinishInputEvent += FinishInputUpdater;

			// モーダルの場合は記載不要。
			// モードレスの場合、これを記載しないと子ウィンドウ側でASCIIを入力できない。
			ElementHost.EnableModelessKeyboardInterop(window);

#if false
			window.Show();
#else
			window.ShowDialog();
#endif
		}

		private void FinishInputUpdater(object sender, EventArgs e)
		{
			txb_name.Text = window.name;
			txb_telephone.Text = window.phone;
			txb_address.Text = window.address;
		}

		private void Form1_Load(object sender, EventArgs e)
		{
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
		}
	}
}
