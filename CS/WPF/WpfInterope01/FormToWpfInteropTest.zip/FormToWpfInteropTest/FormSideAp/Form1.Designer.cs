﻿namespace FormSideAp
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_NewWindow = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txb_name = new System.Windows.Forms.TextBox();
            this.txb_telephone = new System.Windows.Forms.TextBox();
            this.txb_address = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_close
            // 
            this.btn_close.Location = new System.Drawing.Point(328, 246);
            this.btn_close.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(125, 50);
            this.btn_close.TabIndex = 0;
            this.btn_close.Text = "Close";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btn_NewWindow
            // 
            this.btn_NewWindow.Location = new System.Drawing.Point(20, 18);
            this.btn_NewWindow.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btn_NewWindow.Name = "btn_NewWindow";
            this.btn_NewWindow.Size = new System.Drawing.Size(162, 44);
            this.btn_NewWindow.TabIndex = 1;
            this.btn_NewWindow.Text = "New Window";
            this.btn_NewWindow.UseVisualStyleBackColor = true;
            this.btn_NewWindow.Click += new System.EventHandler(this.btnNewWindow_Show);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 93);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "名前";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 147);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "電話番号";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 201);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "住所";
            // 
            // txb_name
            // 
            this.txb_name.Location = new System.Drawing.Point(130, 88);
            this.txb_name.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txb_name.Name = "txb_name";
            this.txb_name.ReadOnly = true;
            this.txb_name.Size = new System.Drawing.Size(192, 25);
            this.txb_name.TabIndex = 5;
            // 
            // txb_telephone
            // 
            this.txb_telephone.Location = new System.Drawing.Point(130, 142);
            this.txb_telephone.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txb_telephone.Name = "txb_telephone";
            this.txb_telephone.ReadOnly = true;
            this.txb_telephone.Size = new System.Drawing.Size(192, 25);
            this.txb_telephone.TabIndex = 6;
            // 
            // txb_address
            // 
            this.txb_address.Location = new System.Drawing.Point(130, 196);
            this.txb_address.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txb_address.Name = "txb_address";
            this.txb_address.ReadOnly = true;
            this.txb_address.Size = new System.Drawing.Size(192, 25);
            this.txb_address.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(144F, 144F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(473, 314);
            this.Controls.Add(this.txb_address);
            this.Controls.Add(this.txb_telephone);
            this.Controls.Add(this.txb_name);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_NewWindow);
            this.Controls.Add(this.btn_close);
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btn_close;
		private System.Windows.Forms.Button btn_NewWindow;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txb_name;
		private System.Windows.Forms.TextBox txb_telephone;
		private System.Windows.Forms.TextBox txb_address;
	}
}

