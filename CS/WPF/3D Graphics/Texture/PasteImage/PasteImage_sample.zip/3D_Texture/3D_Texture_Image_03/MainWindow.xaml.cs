﻿using System.Windows;
using System.Windows.Input;

namespace _3D_Texture_Image_03
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		private bool _isDrag = false;		// ドラッグ中フラグ true: ドラッグ中、false：ドラッグ中でない
		private Point _Offset;				// ドラッグ開始時点のマウス座標
		private double _oldAngleV;			// ドラッグ開始時点の3D画像回転角（垂直）
		private double _oldAngleH;			// ドラッグ開始時点の3D画像回転角（水平）


		private void ModelUIElement3D_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			// ドラッグ中にする
			_isDrag = true;

			// 3D画像の回転角を取得
			_oldAngleH = holizontal_transform.Angle;
			_oldAngleV = vertical_transform.Angle;

			// マウスの場所を取得
			_Offset = e.GetPosition(this);

			// マウスキャプチャーを取得
			Mouse.Capture(this);
		}

		private void Window_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			// ドラッグ中を解除
			_isDrag = false;

			// マウスキャプチャーを解放
			Mouse.Capture(null);
		}

		private void Window_MouseMove(object sender, MouseEventArgs e)
		{
			// ドラッグ中ならば3D画像を回転
			if (_isDrag == true)
			{
				// マウスの場所を取得
				Point pt = e.GetPosition(this);

				// 3D画像の回転角を更新
				vertical_transform.Angle = (-pt.X + _Offset.X) / 1.0 + _oldAngleV;
				holizontal_transform.Angle = (-pt.Y + _Offset.Y) / 1.0 + _oldAngleH;
			}
		}
	}
}
