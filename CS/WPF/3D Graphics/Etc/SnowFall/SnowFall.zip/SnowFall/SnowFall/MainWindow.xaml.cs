﻿using System.Windows;			// Object
using System.Windows.Media;		// Colors

namespace SnowFall
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{

		private const int _MaxSnow = 100;
		private Snow[] _snow = new Snow[_MaxSnow];

		public MainWindow()
		{
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			CreateSnow();
		}

		private void CreateSnow()
		{
			for ( int i=0; i<_MaxSnow; ++i)
			{
				_snow[i] = SnowFactory.CreateSnowBall(Colors.White, 0.2);
				Model3DG.Children.Add(_snow[i].snowBall);

				_snow[i].BeginAnimation();
			}
		}
	}
}
