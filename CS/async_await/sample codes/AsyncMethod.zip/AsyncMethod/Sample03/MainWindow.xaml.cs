﻿using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Sample03
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // ボタンを無効化
            click_button.IsEnabled = false;

            // ワーカースレッドを作成
            var task = new TaskFactory().StartNew(() => {
                int i = 0;
                for (i = 0; i < 10; ++i)
                {
                    try
                    {
                        this.Dispatcher.Invoke(() =>
                        {
                            // UIタスクへ、ラベルの文字変更を指示
                            counter_label.Content = i.ToString();
                        });

                        Thread.Sleep(1000);
                    }
                    catch (TaskCanceledException)
                    {
                        // スレッド動作中にアプリを終了した場合の異常処理
                        // ここでは例外を無視
                        break;
                    }
                }

                return i;
            });

            // 上の処理が終わったら続けて以下の処理を行います。
            task.ContinueWith((x) =>
            {
                try
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        // Task.Result (intです) を使ってラベルも変えてみます。
                        counter_label.Content = x.Result;

                        // UIタスクへ、ボタン有効化を指示
                        click_button.IsEnabled = true;
                    });
                }
                catch (TaskCanceledException)
                {
                    // スレッド動作中にアプリを終了した場合の異常処理
                    // ここでは例外を無視
                }
            });
        }
    }
}
