﻿using System.Windows;

namespace Sample01
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            click_button.IsEnabled = false;

            for ( int i=0; i<=10; ++i)
            {
                System.Threading.Thread.Sleep(1000);
                counter_label.Content = i.ToString();
            }

            click_button.IsEnabled = true;
        }
    }
}
