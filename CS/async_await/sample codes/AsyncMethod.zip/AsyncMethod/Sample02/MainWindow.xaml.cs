﻿using System.Threading;         // Thread
using System.Threading.Tasks;   // TaskCanceledException
using System.Windows;

namespace Sample02
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // ボタンを無効化
            click_button.IsEnabled = false;

            // ワーカースレッドを作成
            var th = new Thread(() =>
            {
                for ( int i=0; i<=10; ++i)
                {
                    try
                    {
                        this.Dispatcher.Invoke(() =>
                        {
                            // UIタスクへ、ラベルの文字変更を指示
                            counter_label.Content = i.ToString();
                        });

                        Thread.Sleep(1000);
                    }
                    catch(TaskCanceledException)
                    {
                        // スレッド動作中にアプリを終了した場合の異常処理
                        // ここでは例外を無視
                        break;
                    }
                }

                try
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        // UIタスクへ、ボタン有効化を指示
                         click_button.IsEnabled = true;
                    });
                }
                catch(TaskCanceledException)
                {
                    // スレッド動作中にアプリを終了した場合の異常処理
                    // ここでは例外を無視
                }
            });

            // ワーカースレッドを実行
            th.Start();
        }
    }
}
