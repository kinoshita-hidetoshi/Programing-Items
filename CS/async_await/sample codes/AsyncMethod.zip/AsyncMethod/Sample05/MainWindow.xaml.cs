﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Sample05
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Action func = async () =>
            {
                // ボタンを無効化
                click_button.IsEnabled = false;

                int i = 0;
                for (i = 0; i < 10; i++)
                {
                    // label 更新
                    counter_label.Content = i.ToString();

                    // １秒待機
                    await Task.Run(() =>
                    {
                        Thread.Sleep(1000);
                    });
                }

                // label 更新
                counter_label.Content = i.ToString();

                // ボタンを有効化
                click_button.IsEnabled = true;
            };

            func();
        }
    }
}
