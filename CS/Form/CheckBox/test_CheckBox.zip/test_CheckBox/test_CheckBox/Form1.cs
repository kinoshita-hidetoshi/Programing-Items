﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test_CheckBox
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();

			// プログラム起動時に label1 の表示を初期化する。
			checkBox1_CheckStateChanged(this, new EventArgs());
		}

		private void checkBox1_CheckStateChanged(object sender, EventArgs e)
		{
			switch (checkBox1.CheckState)
			{
			case CheckState.Unchecked:
				label1.Text = "Unchecked";
				break;
			case CheckState.Checked:
				label1.Text = "Checked";
				break;
			case CheckState.Indeterminate:
				label1.Text = "Interminate";
				break;
			default:
				break;
			}
		}
	}
}
