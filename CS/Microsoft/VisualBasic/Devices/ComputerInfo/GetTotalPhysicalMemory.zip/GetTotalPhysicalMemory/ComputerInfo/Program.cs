﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.VisualBasic;


namespace ComputerInfo
{
	class Program
	{
		static void Main(string[] args)
		{
			var info = new Microsoft.VisualBasic.Devices.ComputerInfo();

			Console.WriteLine("AvailablePhysicalMemory: " + info.AvailablePhysicalMemory.ToString("#,00"));
			Console.WriteLine("AvailableVirtualMemory:  " + info.AvailableVirtualMemory.ToString("#,00"));
			Console.WriteLine("InstalledUICulture:      " + info.InstalledUICulture);
			Console.WriteLine("OSFullName:              " + info.OSFullName);
			Console.WriteLine("OSPlatform:              " + info.OSPlatform);
			Console.WriteLine("OSVersion:               " + info.OSVersion);
			Console.WriteLine("TotalPhysicalMemory:     " + info.TotalPhysicalMemory.ToString("#,00"));
			Console.WriteLine("TotalVirtualMemory:      " + info.TotalVirtualMemory.ToString("#,00"));
			Console.WriteLine("Is64BitOperatingSystem:  " + Environment.Is64BitOperatingSystem);
			Console.WriteLine("===============================================");
			Console.Write("HIT [Enter] KEY !! ");
			Console.ReadLine();
		}
	}
}
