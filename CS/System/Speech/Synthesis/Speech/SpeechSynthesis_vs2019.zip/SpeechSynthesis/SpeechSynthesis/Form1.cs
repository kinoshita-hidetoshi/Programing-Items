﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Speech.Synthesis;	// SpeechSynthesizer


namespace SpeechSynthesis
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void button2_Click(object sender, EventArgs e)
		{
#if true // SpeakAsync で発生する場合は、 false にすると音が出なくなります。
			var synth = new SpeechSynthesizer();
#else
			using (var synth = new SpeechSynthesizer())
#endif
			{
				synth.SelectVoiceByHints(VoiceGender.Female);
				synth.SpeakAsync(textBox1.Text);
				//synth.Speak(textBox1.Text);
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
#if true
			var synth = new SpeechSynthesizer();
#else
			using (var synth = new SpeechSynthesizer())
#endif
			{
				synth.SelectVoiceByHints(VoiceGender.Male);
				string message = "こんにちは。日本語をしゃべるテストプログラムです。お試しください。";
				synth.SpeakAsync(message);
			}
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
#if true
			var synth = new SpeechSynthesizer();
#else
			using (var synth = new SpeechSynthesizer())
#endif
			{
				synth.SelectVoiceByHints(VoiceGender.Male);
				string message = "プログラムを終了してよろしいですか？";
				synth.SpeakAsync(message);
			}
			if (MessageBox.Show("プログラムを終了してよろしいですか？", "終了確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.No)
			{
				e.Cancel = true;
			}
		}
	}
}
