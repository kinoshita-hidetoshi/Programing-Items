﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Ipc;

using IpcSample;


namespace Client
{
	class Program
	{
		private static IpcClient _ipcClient;

		static void Main(string[] args)
		{
			System.Threading.Thread.Sleep(2000);

			_ipcClient = new IpcClient();


			// メイン処理
			ThreadPool.QueueUserWorkItem(new WaitCallback(MethodTest));


			// 終了待ち
			Console.Write("HIT [Enter] KEY !! ");
			Console.ReadLine();
		}


		private static void MethodTest(Object obj)
		{
			for ( int i=0; i<3000; ++i)
			{
				Thread.Sleep(1000);
				_ipcClient.remoteObject.Counter++;
				Console.WriteLine("Counter = "+_ipcClient.remoteObject.Counter);
			}

		}
	}


	class IpcClient
	{
		public IpcRemoteObject remoteObject { private set; get; }

		public IpcClient()
		{
			// クライアントチャネルの作成
			IpcClientChannel channel = new IpcClientChannel();

			// チャンネルを登録
			ChannelServices.RegisterChannel(channel, true);

			// リモートオブジェクトを取得
			remoteObject = Activator.GetObject(typeof(IpcRemoteObject), "ipc://IpcSample/test") as IpcRemoteObject;
		}
	}
}
