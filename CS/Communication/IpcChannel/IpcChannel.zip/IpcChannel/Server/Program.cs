﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Ipc;

using IpcSample;

namespace Server
{
	class Program
	{
		private static IpcServer _ipcServer;

		static void Main(string[] args)
		{
			_ipcServer = new IpcServer();
			_ipcServer.remoteObject.counterChangeEvent += CounterChangeEventHandler;

			// メイン処理
			//ThreadPool.QueueUserWorkItem(new WaitCallback(MethodTest));


			// 終了待ち
			Console.Write("HIT [Enter] KEY !! ");
			Console.ReadLine();
		}

		private static void MethodTest(Object obj)
		{
			int lastCount = -1;

			while(_ipcServer.remoteObject.Counter < 10){
				Thread.Sleep(100);
				if ( _ipcServer.remoteObject.Counter != lastCount)
				{
					Console.WriteLine("Counter = " + _ipcServer.remoteObject.Counter);
					lastCount = _ipcServer.remoteObject.Counter;
				}
			}
		}

		private static void CounterChangeEventHandler(object sender, EventArgs e)
		{
			Console.WriteLine("[CounterChangeEventHandler] Counter = " + _ipcServer.remoteObject.Counter);
		}
	}


	class IpcServer
	{
		public IpcRemoteObject remoteObject { private set; get; }

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public IpcServer()
		{
			// サーバーチャンネルの作成
			IpcServerChannel channel = new IpcServerChannel("IpcSample");

			// チャンネルを登録
			ChannelServices.RegisterChannel(channel, true);

			// リモートオブジェクトを生成して公開
			remoteObject = new IpcRemoteObject();
			RemotingServices.Marshal(remoteObject, "test", typeof(IpcRemoteObject));
		}
	}
}
