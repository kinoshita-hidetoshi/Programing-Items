﻿using System;
using System.Runtime.Remoting.Lifetime;

namespace IpcSample
{
	public class IpcRemoteObject : MarshalByRefObject
    {
		public delegate void CounterChangeEventHandler(object sender, EventArgs e);
		public event CounterChangeEventHandler counterChangeEvent;

		private int _counter;
		public int Counter {
			set {
				_counter = value;
				if ( counterChangeEvent != null)
				{
					counterChangeEvent(this, new EventArgs());
				}
			}
			get {
				return _counter;
			}
		}

#if true
		public override Object InitializeLifetimeService()
		{
			// このオブジェクトのリース期限を無制限にします。 
			ILease lease = (ILease)base.InitializeLifetimeService();
			if (lease.CurrentState == LeaseState.Initial)
			{
				lease.InitialLeaseTime = TimeSpan.Zero;
				//lease.InitialLeaseTime = TimeSpan.FromSeconds(15);
			}
			return lease;
		}
#endif
	}
}
