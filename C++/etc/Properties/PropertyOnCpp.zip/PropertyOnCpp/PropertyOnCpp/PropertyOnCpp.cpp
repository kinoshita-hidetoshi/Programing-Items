#include <stdio.h>
#include <tchar.h>
#include <cstdlib>
#include <iostream>
#include <string>

#include "property.h"


using namespace std;
using namespace hidetoshi;


template <class T>
class IDProperty : public Property<T>
{
private:

public:
	IDProperty()
	{
	}

	virtual operator T() const
	{
		return data_;
	}

	virtual T operator = ( T const & value )
	{
		data_ = value;
		return data_;
	}
};


class myClass {
private:
	// for RO
	int numKids_ ;
	int get_numKids()
	{
		return numKids_;
	}

	// for WO
	float weight_;
	float set_Weight( float const & value )
	{
		weight_ = value ;
		return value;
	}

	// for RW
	std::string secretkey_;
	std::string set_Secretkey( const std::string& key )
	{
		return (secretkey_ = key);
	}
	std::string get_Secretkey()
	{
		return secretkey_;
	}


public:
	// Name and ID are read-write properties with automatic data store
	Property<std::string> Name ;
	IDProperty<long> ID ;

	// Number_of_children is a read-only property
	ROProperty< int, myClass, &myClass::get_numKids >	NumberOfChildren;
	// WeightedValue is a write-only property
	WOProperty< float, myClass, &myClass::set_Weight >	WeightedValue;
	// Secretkey is a read-write property calling user-defined functions
	RWProperty< std::string, myClass, &myClass::get_Secretkey, &myClass::set_Secretkey >	Secretkey;

	// Constructor
	myClass()
		: numKids_(24), weight_(60), secretkey_("This is a initial secret key.")
	{
		NumberOfChildren( this );
		WeightedValue( this );
		Secretkey( this );
	}
};



int _tmain(int argc, _TCHAR* argv[])
{
	/*========*/
	/* �O���� */
	/*========*/

	/*========*/
	/* ������ */
	/*========*/
	{
		myClass thing;

		// Property<> members:
		{
			thing.Name = "Pinkie Platypus";
			string s1 = thing.Name;
			cout << "Name = " << s1 << endl;

			thing.ID = 12345678;
			long id = thing.ID;
			cout << "ID = " << id << endl;

			cout << endl;
		}

		// ROProperty<> member
		{
			int brats ;
			brats = thing.NumberOfChildren;
			cout << "Children = " << brats << endl;
			cout << endl;
		}

		// WOProperty<> member
		{
			thing.WeightedValue = 1.618034f;
//			cout << thing.WeightedValue << endl;	// �ǂݎ��ł��܂���
//			cout << endl;
		}

		// RWProperty<> member
		{
			thing.Secretkey = "?????";
			std::string key = thing.Secretkey;
			std::cout << "Secretkey = " << key << std::endl;
			std::cout << std::endl;
		}
	}

	/*========*/
	/* �㏈�� */
	/*========*/
	{
		string str ;

		cout << "HIT [Enter] KEY !! " ;
		getline( cin, str );
	}
	return EXIT_SUCCESS;

}
