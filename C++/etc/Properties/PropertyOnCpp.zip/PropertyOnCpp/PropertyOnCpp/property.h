//
// [�Q�ƕ���]
// http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2004/n1615.pdf
//

#ifndef HIDETOSHI_PROPERTY
#define HIDETOSHI_PROPERTY


#include <map>


namespace hidetoshi {

// a read-write property with data store and
// automatically generated get/set functions.
// this is what C++/CLI calls a trivial scalar property
template <class T>
class Property
{
private:

protected:
	T data_;

public:
	// Constructor
	Property() : data_(T()) {
	}

	virtual operator T() const
	{
		return data_;
	}

	virtual T operator = ( T const & value )
	{
		data_ = value;
		return data_;
	}

	typedef T value_type; // might be useful for template deductions
};



// a read-only property calling a user-defined getter
template <class T, class Object, typename T (Object::*real_getter)()>
class ROProperty
{
private:
	Object * my_object;

public:
	// Constructor
	ROProperty() : my_object(nullptr)
	{
	}

	void operator () ( Object * obj )
	{
		my_object = obj;
	}

	void set( T const & value ); // reserved but not implemented, per C++/CLI

	// access with '=' sign
	operator T() const
	{
		if ( my_object == nullptr ){
			throw std::logic_error("ERROR: Invalid use of the class ROProperty, my_object is not initialized.");
		}
		return (my_object->*real_getter)();
	}

	typedef T value_type; // might be useful for template deductions
};



// a write-only property calling a user-defined setter
template < class T, class Object, typename T (Object::*real_setter)( T const & ) >
class WOProperty
{
private:
	Object * my_object;

public:
	// Constructor
	WOProperty() : my_object(nullptr)
	{
	}

	void operator () ( Object * obj )
	{
		my_object = obj;
	}

	// access with '=' sign
	T operator = ( T const & value )
	{
		if ( my_object == nullptr ){
			throw std::logic_error("ERROR: Invalid use of the class WOProperty, my_object is not initialized.");
		}
		return (my_object->*real_setter)( value );
	}

	typedef T value_type; // might be useful for template deductions
};



// a read-write property which invokes user-defined functions
template < class T, class Object, typename T (Object::*real_getter)(), typename T (Object::*real_setter)( T const & ) >
class RWProperty
{
private:
	Object * my_object;

public:
	void operator () ( Object * obj )
	{
		my_object = obj;
	}

#if 0
	T operator()() const
	{
		return (my_object->*real_getter)();
	}

	T operator()( T const & value )
	{
		return (my_object->*real_setter)( value );
	}

	T get() const
	{
		return (my_object->*real_getter)();
	}

	T set( T const & value )
	{
		return (my_object->*real_setter)( value );
	}
#endif

	// access with '=' sign
	operator T() const
	{
		return (my_object->*real_getter)();
	}

	T operator = ( T const & value )
	{
		return (my_object->*real_setter)( value );
	}

	typedef T value_type; // might be useful for template deductions
};


} // namespace hidetoshi

#endif // HIDETOSHI_PROPERTY
