#pragma once

#include "resource1.h"
