//
// Aes.h
//

namespace aes_library {

enum AES_ERROR_CODE {
	NORMAL				= 0,
	INVALID_ALGORITHM	= 100,
	INVALID_ARGUMENT,
	INVALID_KEY_LENGTH,
	LOGIC_ERROR
};

const size_t	AES_KEY_SIZE = 16 ;

bool createAesKey( std::string passFraise, unsigned char (&aesKey)[AES_KEY_SIZE],  AES_ERROR_CODE &errorCode );
bool encryptData( unsigned char* rawData, size_t sizeRawData, unsigned char (&keyData)[AES_KEY_SIZE], unsigned char* cryptData, size_t sizeCryptData, size_t &cryptDataBytes, AES_ERROR_CODE &errorCode );
bool decryptData( unsigned char* cryptData, size_t sizeCryptData, unsigned char (&keyData)[AES_KEY_SIZE], unsigned char* rawData, size_t sizeRawData, size_t &rawDataBytes, AES_ERROR_CODE &errorCode );

} // namespace aes_library
