﻿/*

Copyright (c) 2005-2017 KINOSHITA Hidetoshi

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF 
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

--------------------------------------------------------------------------

Copyright (c) 2005-2017 木下英俊

以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル（以下「ソフ
トウェア」）の複製を取得するすべての人に対し、ソフトウェアを無制限に扱うこ
とを無償で許可します。これには、ソフトウェアの複製を使用、複写、変更、結合
、掲載、頒布、サブライセンス、および／または販売する権利、およびソフトウェ
アを提供する相手に同じことを許可する権利も無制限に含まれます。
 
上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要な
部分に記載するものとします。 

ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの保
証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、お
よび権利非侵害についての保証も含みますが、それに限定されるものではありませ
ん。作者または著作権者は、契約行為、不法行為、またはそれ以外であろうと、ソ
フトウェアに起因または関連し、あるいはソフトウェアの使用またはその他の扱い
によって生じる一切の請求、損害、その他の義務について何らの責任も負わないも
のとします。

*/

/*=========================================================*/
/*! @file
    @brief	PCの各種ｼｽﾃﾑ情報を取得するための関数

	GetSystemInformations.c というファイル名で記載されています。
	対応するヘッダファイルは GetSystemInformations.h です。

    @author	木下英俊
    @date   2005-06-05 新規作成
	@date	2012-03-11 "Windows 7", "Windows 2008 Server R2", 他, に対応
	@date	2012-03-11 locGetProductInfo を追加
	@date	2012-11-24 "Windows 8", "Windows Server 2012" に対応
	@date	2013-10-28 "Windows 8.1", "Windows Server 2012 R2" に対応
	@date	2017-02-22 "Windows 10", "Windows Server 2016" に対応
	*/
/*=========================================================*/

#include <windows.h>					// LoadLibrary, FreeLibrary
#include <tchar.h>						// _T(""), TCHAR, _tcsncpy_s
#include <string>						// string, wstring

#include "GetSystemInformations.h"		// 自分自身のヘッダファイル


namespace {
/*=========================================================*/
/*!
    Windowsに関する プロダクト情報 を取得する。
    
    @param[out]		cProductInfo    プロダクト情報 格納用変数
    @param[in]		dwProductInfo   cProductInfo に格納可能なデータサイズ
    @retval			TRUE            正常終了
    @retval			FALSE           異常終了
	@author			木下英俊
	@date			2012-03-11 新規作成
	@date			2012-11-24 PRODUCT_CORE_* の5種類を追加。Windows8対応の一環。

	@note{
	下記ページを参照 \n
	https://msdn.microsoft.com/en-us/library/windows/desktop/ms724358(v=vs.85).aspx
	}
*/
/*=========================================================*/
BOOL GetProductInfo( TCHAR* cProductInfo, size_t dwProductInfo )
{
	HMODULE			hModule ;
	//BOOL			ret = TRUE ;
	BOOL			ret = FALSE;
	DWORD			dwType = 0 ;
#ifdef _UNICODE
	std::wstring	strMessage ;
#else
	std::string		strMessage ;
#endif
	


	BOOL (WINAPI * pfnGetProductInfo)(DWORD dwOSMajorVersion, DWORD dwOSMinorVersion, DWORD dwSpMajorVersion, DWORD dwSpMinorVersion, PDWORD pdwReturnedProductType );
	

	hModule = ::LoadLibrary(_T("kernel32.dll"));
	if (hModule == NULL){
		return	false;
	}
	
	(*(FARPROC*)&pfnGetProductInfo) = ::GetProcAddress(hModule, "GetProductInfo");

	if ( pfnGetProductInfo != NULL ){
		OSVERSIONINFOEX	sInfoEx;

		::ZeroMemory(&sInfoEx,sizeof(OSVERSIONINFOEX));
		sInfoEx.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
		ret = ::GetVersionEx((LPOSVERSIONINFO)&sInfoEx);

		if ( ret ){
			ret = pfnGetProductInfo(sInfoEx.dwMajorVersion,sInfoEx.dwMinorVersion, sInfoEx.wServicePackMajor, sInfoEx.wServicePackMinor, &dwType);
		}
	}

	if (ret){
		switch(dwType){
		case	PRODUCT_BUSINESS:
			strMessage = _T("PRODUCT_BUSINESS");
			break;

		case	PRODUCT_BUSINESS_N:
			strMessage = _T("PRODUCT_BUSINESS_N");
			break;

		case	PRODUCT_CLUSTER_SERVER:
			strMessage = _T("PRODUCT_CLUSTER_SERVER");
			break;

		/* <= Windows8 対応で追加 */

		case	PRODUCT_CORE_ARM:
			strMessage = _T("PRODUCT_CORE_ARM");
			break;

		case	PRODUCT_CORE_N:
			strMessage = _T("PRODUCT_CORE_N");
			break;

		case	PRODUCT_CORE_COUNTRYSPECIFIC:
			strMessage = _T("PRODUCT_CORE_COUNTRYSPECIFIC");
			break;

		case	PRODUCT_CORE_SINGLELANGUAGE:
			strMessage = _T("PRODUCT_CORE_SINGLELANGUAGE");
			break;

		case	PRODUCT_CORE:
			//strMessage = _T("PRODUCT_CORE");
			strMessage = _T("Home");
			break;

		/* Windows8 対応で追加 => */

		case	PRODUCT_DATACENTER_SERVER:
			strMessage = _T("PRODUCT_DATACENTER_SERVER");
			break;

		case	PRODUCT_DATACENTER_SERVER_CORE:
			strMessage = _T("PRODUCT_DATACENTER_SERVER_CORE");
			break;

		case	PRODUCT_DATACENTER_SERVER_CORE_V:
			strMessage = _T("PRODUCT_DATACENTER_SERVER_CORE_V");
			break;

		case	PRODUCT_DATACENTER_SERVER_V:
			strMessage = _T("PRODUCT_DATACENTER_SERVER_V");
			break;

		case	PRODUCT_ENTERPRISE:
			strMessage = _T("PRODUCT_ENTERPRISE");
			break;

		case	PRODUCT_ENTERPRISE_E:
			strMessage = _T("PRODUCT_ENTERPRISE_E");
			break;

		case	PRODUCT_ENTERPRISE_N:
			strMessage = _T("PRODUCT_ENTERPRISE_N");
			break;

		case	PRODUCT_ENTERPRISE_SERVER:
			strMessage = _T("PRODUCT_ENTERPRISE_SERVER");
			break;

		case	PRODUCT_ENTERPRISE_SERVER_CORE:
			strMessage = _T("PRODUCT_ENTERPRISE_SERVER_CORE");
			break;

		case	PRODUCT_ENTERPRISE_SERVER_CORE_V:
			strMessage = _T("PRODUCT_ENTERPRISE_SERVER_CORE_V");
			break;

		case	PRODUCT_ENTERPRISE_SERVER_IA64:
			strMessage = _T("PRODUCT_ENTERPRISE_SERVER_IA64");
			break;

		case	PRODUCT_ENTERPRISE_SERVER_V:
			strMessage = _T("PRODUCT_ENTERPRISE_SERVER_V");
			break;

		case	PRODUCT_HOME_BASIC:
			strMessage = _T("PRODUCT_HOME_BASIC");
			break;

		case	PRODUCT_HOME_BASIC_E:
			strMessage = _T("PRODUCT_HOME_BASIC_E");
			break;

		case	PRODUCT_HOME_BASIC_N:
			strMessage = _T("PRODUCT_HOME_BASIC_N");
			break;

		case	PRODUCT_HOME_PREMIUM:
			strMessage = _T("PRODUCT_HOME_PREMIUM");
			break;

		case	PRODUCT_HOME_PREMIUM_E:
			strMessage = _T("PRODUCT_HOME_PREMIUM_E");
			break;

		case	PRODUCT_HOME_PREMIUM_N:
			strMessage = _T("PRODUCT_HOME_PREMIUM_N");
			break;

		case	PRODUCT_HOME_SERVER:
			strMessage = _T("PRODUCT_HOME_SERVER");
			break;

		case	PRODUCT_HYPERV:
			strMessage = _T("PRODUCT_HYPERV");
			break;

		case	PRODUCT_MEDIUMBUSINESS_SERVER_MANAGEMENT:
			strMessage = _T("PRODUCT_MEDIUMBUSINESS_SERVER_MANAGEMENT");
			break;

		case	PRODUCT_MEDIUMBUSINESS_SERVER_MESSAGING:
			strMessage = _T("PRODUCT_MEDIUMBUSINESS_SERVER_MESSAGING");
			break;

		case	PRODUCT_MEDIUMBUSINESS_SERVER_SECURITY:
			strMessage = _T("PRODUCT_MEDIUMBUSINESS_SERVER_SECURITY");
			break;

		case	PRODUCT_PROFESSIONAL:
			strMessage = _T("PRODUCT_PROFESSIONAL");
			break;

		case	PRODUCT_PROFESSIONAL_E:
			strMessage = _T("PRODUCT_PROFESSIONAL_E");
			break;

		case	PRODUCT_PROFESSIONAL_N:
			strMessage = _T("PRODUCT_PROFESSIONAL_N");
			break;

		case	PRODUCT_SERVER_FOR_SMALLBUSINESS:
			strMessage = _T("PRODUCT_SERVER_FOR_SMALLBUSINESS");
			break;

		case	PRODUCT_SERVER_FOR_SMALLBUSINESS_V:
			strMessage = _T("PRODUCT_SERVER_FOR_SMALLBUSINESS_V");
			break;

		case	PRODUCT_SERVER_FOUNDATION:
			strMessage = _T("PRODUCT_SERVER_FOUNDATION");
			break;

		case	PRODUCT_SMALLBUSINESS_SERVER:
			strMessage = _T("PRODUCT_SMALLBUSINESS_SERVER");
			break;

		case	PRODUCT_SMALLBUSINESS_SERVER_PREMIUM:
			strMessage = _T("PRODUCT_SMALLBUSINESS_SERVER_PREMIUM");
			break;

		case	PRODUCT_STANDARD_SERVER:
			strMessage = _T("PRODUCT_STANDARD_SERVER");
			break;

		case	PRODUCT_STANDARD_SERVER_CORE:
			strMessage = _T("PRODUCT_STANDARD_SERVER_CORE");
			break;

		case	PRODUCT_STANDARD_SERVER_CORE_V:
			strMessage = _T("PRODUCT_STANDARD_SERVER_CORE_V");
			break;

		case	PRODUCT_STANDARD_SERVER_V:
			strMessage = _T("PRODUCT_STANDARD_SERVER_V");
			break;

		case	PRODUCT_STARTER:
			strMessage = _T("PRODUCT_STARTER");
			break;

		case	PRODUCT_STARTER_E:
			strMessage = _T("PRODUCT_STARTER_E");
			break;

		case	PRODUCT_STARTER_N:
			strMessage = _T("PRODUCT_STARTER_N");
			break;

		case	PRODUCT_STORAGE_ENTERPRISE_SERVER:
			strMessage = _T("PRODUCT_STORAGE_ENTERPRISE_SERVER");
			break;

		case	PRODUCT_STORAGE_EXPRESS_SERVER:
			strMessage = _T("PRODUCT_STORAGE_EXPRESS_SERVER");
			break;

		case	PRODUCT_STORAGE_STANDARD_SERVER:
			strMessage = _T("PRODUCT_STORAGE_STANDARD_SERVER");
			break;

		case	PRODUCT_STORAGE_WORKGROUP_SERVER:
			strMessage = _T("PRODUCT_STORAGE_WORKGROUP_SERVER");
			break;

		case	PRODUCT_UNDEFINED:
			strMessage = _T("PRODUCT_UNDEFINED");
			break;

		case	PRODUCT_ULTIMATE:
			strMessage = _T("PRODUCT_ULTIMATE");
			break;

		case	PRODUCT_ULTIMATE_E:
			strMessage = _T("PRODUCT_ULTIMATE_E");
			break;

		case	PRODUCT_ULTIMATE_N:
			strMessage = _T("PRODUCT_ULTIMATE_N");
			break;

		case	PRODUCT_WEB_SERVER:
			strMessage = _T("PRODUCT_WEB_SERVER");
			break;

		case	PRODUCT_WEB_SERVER_CORE:
			strMessage = _T("PRODUCT_WEB_SERVER_CORE");
			break;

		default:
			strMessage = _T("Unknown Type");
			break;
		}
	}

	::FreeLibrary(hModule);

	_tcsncpy_s( cProductInfo, dwProductInfo, strMessage.c_str(), _TRUNCATE );

	return	true;
}

} // namespace


/*===============================================================================*/
/*!
	Windowsに関するプラットフォーム、バージョン番号、ビルド番号などを取得する。
	
	@param[out]		windows			プラットフォーム名 格納用変数
	@param[in]		nWindows		windows の変数サイズ
	@param[out]		version			バージョン番号 格納用変数
	@param[in]		nVersion		cVersion の変数サイズ
	@param[out]		build			ビルド番号 格納用変数
	@param[in]		nuild			cBuild の変数サイズ
	@retval			TRUE			正常終了
	@retval			FALSE			異常終了
	@author			木下英俊
    @date   2005-06-05 新規作成
	@date	2012-03-11 Windows7, 2008ServerR2, 他, に対応
	@date	2012-03-11 locGetProductInfo を追加
	@date	2012-11-24 "Windows 8", "Windows Server 2012" に対応
	@date	2013-10-28 "Windows 8.1", "Windows Server 2012 R2" に対応
	@date	2017-02-22 "Windows 10", "Windows Server 2016" に対応
*/
/*===============================================================================*/
BOOL GetWindowsInformations( TCHAR* windows, size_t nWindows, TCHAR* version, size_t nVersion, TCHAR* build, size_t nBuild )
{
	BOOL			bRet = FALSE ;
	OSVERSIONINFOEX	VersionInformationEx ;
	
	
	/*========*/
	/* 前処理 */
	/*========*/
	ZeroMemory(&VersionInformationEx, sizeof(OSVERSIONINFOEX));
	VersionInformationEx.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	
	/*========*/
	/* 処理部 */
	/*========*/
	if (!GetVersionEx((LPOSVERSIONINFO)&VersionInformationEx)){
		// GetVersionEx 失敗
		MessageBox( NULL, _T("API GetVersionEx() に失敗しました。"), _T("ERROR 情報"), MB_OK|MB_ICONWARNING);
		bRet = FALSE ;
	}
	else{
		// GetVersionEx 成功
		bRet = TRUE ;

		// ﾌﾟﾗｯﾄﾌｫｰﾑ情報(他) 取得
		switch (VersionInformationEx.dwPlatformId){
		case VER_PLATFORM_WIN32s:
			_tcsncpy_s( windows, nWindows, _T("Win32s on Windows 3.1"), _TRUNCATE);
			break ;

		case VER_PLATFORM_WIN32_WINDOWS:
			switch ( VersionInformationEx.dwMinorVersion ){
			case 0:
				// Windows 95
				_tcsncpy_s(windows, nWindows, _T("Windows 95"), _TRUNCATE);
				break ;
			case 10:
				// Windows 98
				_tcsncpy_s(windows, nWindows, _T("Windows 98"), _TRUNCATE);
				break ;
			case 90:
				// Windows Me
				_tcsncpy_s(windows, nWindows, _T("Windows Me"), _TRUNCATE);
				break ;
			default:
				// Unknown Windows 95 family
				_tcsncpy_s(windows, nWindows, _T("Unknown Windows 95 family"), _TRUNCATE);
				break ;
			}
			break ;

		case VER_PLATFORM_WIN32_NT:
			switch (VersionInformationEx.dwMajorVersion){
			case 3:
			case 4:
				// Windows NT
				_tcsncpy_s(windows, nWindows, _T("Windows NT"), _TRUNCATE);
				break ;

			case 5:
				switch (VersionInformationEx.dwMinorVersion){
				case 0:
					// Windows 2000
					_tcsncpy_s(windows, nWindows, _T("Windows 2000"), _TRUNCATE);
					break ;
				case 1:
					// Windows XP
					_tcsncpy_s(windows, nWindows, _T("Windows XP"), _TRUNCATE);
					if ( (VersionInformationEx.wSuiteMask & VER_SUITE_PERSONAL)==VER_SUITE_PERSONAL ){
						_tcsncpy_s(windows, nWindows, _T(" Home edition"), _TRUNCATE);
					}
					else{
						_tcsncpy_s(windows, nWindows, _T(" Professional"), _TRUNCATE);
					}
					break ;
				case 2:
					// Windows Server 2003 family
					_tcsncpy_s(windows, nWindows, _T("Windows Server 2003 family"), _TRUNCATE);
					break ;
				default:
					// Unknown Windows NT family
					_tcsncpy_s(windows, nWindows, _T("Unknown Windows NT family"), _TRUNCATE);
					break ;
				}
				break ;

			case 6:
				switch (VersionInformationEx.dwMinorVersion){
				case 0:
					if( VersionInformationEx.wProductType == VER_NT_WORKSTATION ){
						// Windows Vista
						_tcsncpy_s(windows, nWindows, _T("Windows Vista"), _TRUNCATE);
					}
					else{
						// Windows Server 2008
						_tcsncpy_s(windows, nWindows, _T("Windows Server 2008"), _TRUNCATE);
					}
					break ;
				case 1:
					if( VersionInformationEx.wProductType == VER_NT_WORKSTATION ){
						// Windows 7
						_tcsncpy_s(windows, nWindows, _T("Windows 7"), _TRUNCATE);
					}
					else{
						// Windows Server 2008 R2
						_tcsncpy_s(windows, nWindows, _T("Windows Server 2008 R2"), _TRUNCATE);
					}
					break ;
				case 2:
					if( VersionInformationEx.wProductType == VER_NT_WORKSTATION ){
						// Windows 8
						_tcsncpy_s(windows, nWindows, _T("Windows 8"), _TRUNCATE);
					}
					else{
						// Windows Server 2012
						_tcsncpy_s(windows, nWindows, _T("Windows Server 2012"), _TRUNCATE);
					}
					break ;
				case 3:
					if( VersionInformationEx.wProductType == VER_NT_WORKSTATION ){
						// Windows 8.1
						_tcsncpy_s(windows, nWindows, _T("Windows 8.1"), _TRUNCATE);
					}
					else{
						// Windows Server 2012 R2
						_tcsncpy_s(windows, nWindows, _T("Windows Server 2012 R2"), _TRUNCATE);
					}
					break;
				default:
					if( VersionInformationEx.wProductType == VER_NT_WORKSTATION ){
						// Unknown Windows family
						_tcsncpy_s(windows, nWindows, _T("Unknown Windows family"), _TRUNCATE);
					}
					else{
						// Unknown Windows Server family
						_tcsncpy_s(windows, nWindows, _T("Unknown Windows Server family"), _TRUNCATE);
					}
					break ;
				}

				// Product Information を取得
				{
					TCHAR	cProductInfo[1024] = _T("");
					GetProductInfo( cProductInfo, (sizeof(cProductInfo)/sizeof(cProductInfo[0])) );
					_tcsncat_s( windows, nWindows, _T(" "), _TRUNCATE );
					_tcsncat_s( windows, nWindows, cProductInfo, _TRUNCATE );
				}
				break ;

			case 10:
				switch (VersionInformationEx.dwMinorVersion) {
				case 0:
					if (VersionInformationEx.wProductType == VER_NT_WORKSTATION) {
						// Windows Vista
						_tcsncpy_s(windows, nWindows, _T("Windows 10"), _TRUNCATE);
					}
					else {
						// Windows Server 2016
						_tcsncpy_s(windows, nWindows, _T("Windows Server 2016"), _TRUNCATE);
					}
					break;
				default:
					if (VersionInformationEx.wProductType == VER_NT_WORKSTATION) {
						// Unknown Windows family
						_tcsncpy_s(windows, nWindows, _T("Unknown Windows family"), _TRUNCATE);
					}
					else {
						// Unknown Windows Server family
						_tcsncpy_s(windows, nWindows, _T("Unknown Windows Server family"), _TRUNCATE);
					}
					break;
				}

				// Product Information を取得
				{
					TCHAR	cProductInfo[1024] = _T("");
					GetProductInfo(cProductInfo, (sizeof(cProductInfo) / sizeof(cProductInfo[0])));
					_tcsncat_s(windows, nWindows, _T(" "), _TRUNCATE);
					_tcsncat_s(windows, nWindows, cProductInfo, _TRUNCATE);
				}
				break;

			default:
				// Unknown Windows NT family
				_tcsncpy_s(windows, nWindows, _T("Unknown Windows NT family"), _TRUNCATE);
				break ;
			}
			break ;

		default:
			// No Windows
			_tcsncpy_s( windows, nWindows, _T("No Windows"), _TRUNCATE);
			break ;
		}

		// Version情報 取得
		_stprintf_s( version, nVersion, _T("Version %d.%d %s"),
			VersionInformationEx.dwMajorVersion,
			VersionInformationEx.dwMinorVersion,
			VersionInformationEx.szCSDVersion) ;
		
		// Build情報 取得
		_stprintf_s( build, nBuild, _T("Build %d"), VersionInformationEx.dwBuildNumber) ;
	}
	
	/*========*/
	/* 後処理 */
	/*========*/
	return bRet ;
}
